Z-Link Walkie Talkie (Kotlin) - Full project
-------------------------------------------
Conteúdo:
- settings.gradle.kts, build.gradle.kts (raiz)
- app module com fontes em Kotlin, layout e manifest
- implementação demo de PTT via multicast UDP e descoberta via broadcast UDP

Como abrir:
1. Baixe e extraia o ZIP.
2. Abra a pasta no Android Studio (recomendo Android Studio Flamingo ou mais recente).
3. Quando o Android Studio pedir para atualizar Gradle plugin/Wrapper, aceite as recomendações compatíveis.
4. Conceda permissão de microfone em runtime.
5. Teste em dois dispositivos na mesma rede Wi-Fi.

Notas:
- Implementação educativa (não pronto para produção).
- Multicast/broadcast pode ser restrito em algumas redes.
