package com.example.zlink

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.util.Log
import kotlinx.coroutines.*
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.MulticastSocket

class AudioStreamer(private val statusCallback: (String)->Unit) {
    private val TAG = "AudioStreamer"
    private val sampleRate = 16000
    private val channelConfig = AudioFormat.CHANNEL_IN_MONO
    private val audioFormat = AudioFormat.ENCODING_PCM_16BIT
    private val bufferSize = AudioRecord.getMinBufferSize(sampleRate, channelConfig, audioFormat).coerceAtLeast(3200)

    private val groupAddress = InetAddress.getByName("239.0.0.57")
    private val port = 45454

    private var record: AudioRecord? = null
    private var track: AudioTrack? = null

    private var sendJob: Job? = null
    private var recvJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.IO + Job())

    fun startStreaming() {
        if (sendJob?.isActive == true) return
        stopReceiving()
        sendJob = scope.launch {
            try {
                statusCallback("Transmitindo (network)...")
                record = AudioRecord.Builder()
                    .setAudioSource(MediaRecorder.AudioSource.MIC)
                    .setAudioFormat(AudioFormat.Builder()
                        .setEncoding(audioFormat)
                        .setSampleRate(sampleRate)
                        .setChannelMask(channelConfig)
                        .build())
                    .setBufferSizeInBytes(bufferSize)
                    .build()
                record?.startRecording()

                val socket = DatagramSocket()
                val buf = ByteArray(1024)
                while (isActive) {
                    val read = record?.read(buf, 0, buf.size) ?: 0
                    if (read > 0) {
                        val packet = DatagramPacket(buf, read, groupAddress, port)
                        socket.send(packet)
                    } else {
                        delay(10)
                    }
                }

                record?.stop()
                record?.release()
                record = null
                socket.close()
                statusCallback("Pronto")
            } catch (t: Throwable) {
                Log.e(TAG, "send error", t)
                statusCallback("Erro ao transmitir: ${t.localizedMessage}")
            }
        }
    }

    fun stopStreaming() {
        sendJob?.cancel()
        sendJob = null
        startReceiving()
    }

    private fun startReceiving() {
        if (recvJob?.isActive == true) return
        recvJob = scope.launch {
            try {
                statusCallback("Ouvindo (network)...")
                val mSocket = MulticastSocket(port)
                mSocket.joinGroup(groupAddress)
                val buf = ByteArray(2048)

                val min = android.media.AudioTrack.getMinBufferSize(sampleRate,
                    AudioFormat.CHANNEL_OUT_MONO,
                    audioFormat)
                track = AudioTrack.Builder()
                    .setAudioAttributes(AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build())
                    .setAudioFormat(AudioFormat.Builder()
                        .setEncoding(audioFormat)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build())
                    .setBufferSizeInBytes(min * 2)
                    .build()
                track?.play()

                while (isActive) {
                    val packet = DatagramPacket(buf, buf.size)
                    mSocket.receive(packet)
                    track?.write(packet.data, 0, packet.length)
                }

                track?.stop()
                track?.release()
                track = null
                mSocket.leaveGroup(groupAddress)
                mSocket.close()
            } catch (t: Throwable) {
                Log.e(TAG, "recv error", t)
                statusCallback("Erro ao receber: ${t.localizedMessage}")
            }
        }
    }

    private fun stopReceiving() {
        recvJob?.cancel()
        recvJob = null
        try { track?.stop() } catch (_:Exception) {}
        try { track?.release() } catch (_:Exception) {}
        track = null
    }

    fun shutdown() {
        sendJob?.cancel()
        recvJob?.cancel()
        try { record?.release() } catch (_:Exception) {}
        try { track?.release() } catch (_:Exception) {}
        scope.cancel()
    }

    init {
        startReceiving()
    }
}
