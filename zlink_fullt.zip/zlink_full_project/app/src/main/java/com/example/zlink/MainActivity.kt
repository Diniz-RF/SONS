package com.example.zlink

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.MotionEvent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.example.zlink.databinding.ActivityMainBinding
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private var streamer: AudioStreamer? = null
    private var discovery: NetworkDiscovery? = null
    private val scope = CoroutineScope(Dispatchers.Main + Job())

    private val requestRecordPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (!granted) {
            binding.statusText.text = "Permissão de microfone necessária"
        } else {
            binding.statusText.text = "Pronto"
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestRecordPermission.launch(Manifest.permission.RECORD_AUDIO)
        } else {
            binding.statusText.text = "Pronto"
        }

        discovery = NetworkDiscovery(this) { peers ->
            runOnUiThread {
                binding.peersText.text = "Peers: " + peers.joinToString(", ")
            }
        }
        discovery?.start()

        streamer = AudioStreamer { event ->
            runOnUiThread { binding.statusText.text = event }
        }

        binding.pttButton.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    binding.statusText.text = "Transmitindo..."
                    scope.launch { streamer?.startStreaming() }
                    v.isPressed = true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    scope.launch { streamer?.stopStreaming() }
                    binding.statusText.text = "Ouvindo..."
                    v.isPressed = false
                }
            }
            true
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        scope.cancel()
        streamer?.shutdown()
        discovery?.shutdown()
    }
}
