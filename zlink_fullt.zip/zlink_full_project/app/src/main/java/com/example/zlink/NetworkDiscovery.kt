package com.example.zlink

import android.content.Context
import android.util.Log
import kotlinx.coroutines.*
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress

class NetworkDiscovery(private val context: Context, private val onPeersUpdated: (List<String>)->Unit) {
    private val TAG = "NetworkDiscovery"
    private val beaconPort = 45455
    private val beaconMessage = "ZLINK_PRESENCE"
    private val scope = CoroutineScope(Dispatchers.IO + Job())
    private val peers = mutableSetOf<String>()

    fun start() {
        scope.launch {
            launch { receiverLoop() }
            launch { senderLoop() }
        }
    }

    private suspend fun senderLoop() {
        try {
            val socket = DatagramSocket()
            socket.broadcast = true
            val data = beaconMessage.toByteArray()
            val packet = DatagramPacket(data, data.size, InetAddress.getByName("255.255.255.255"), beaconPort)
            while (isActive) {
                socket.send(packet)
                delay(1500)
            }
            socket.close()
        } catch (t: Throwable) {
            Log.e(TAG, "sender error", t)
        }
    }

    private suspend fun receiverLoop() {
        try {
            val socket = DatagramSocket(beaconPort)
            val buf = ByteArray(256)
            while (isActive) {
                val packet = DatagramPacket(buf, buf.size)
                socket.receive(packet)
                val addr = packet.address.hostAddress ?: "?"
                val msg = String(packet.data, 0, packet.length)
                if (msg.contains(beaconMessage)) {
                    peers.add(addr)
                    onPeersUpdated(peers.toList())
                }
            }
            socket.close()
        } catch (t: Throwable) {
            Log.e(TAG, "receiver error", t)
        }
    }

    fun shutdown() {
        scope.cancel()
    }
}
